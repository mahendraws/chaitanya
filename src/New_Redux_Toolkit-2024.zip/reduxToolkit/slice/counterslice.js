import { createSlice } from "@reduxjs/toolkit"

const counterSlice = createSlice({
    name:"counter",
    initialState:10,
    reducers:{  //actions
        increment:(state)=>state+1,
        decrement:(state)=>{
            if(state > 0)
            {
                return state - 1
            }else{
                return state
            }
        
        },
        reset:(state)=>0
    }
})

export const {increment,decrement,reset} = counterSlice.actions

export default counterSlice.reducer