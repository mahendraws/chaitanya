import {configureStore} from '@reduxjs/toolkit'
import counter from './slice/counterslice'
export const store = configureStore({

    reducer:{
        mycounter:counter

    }
})