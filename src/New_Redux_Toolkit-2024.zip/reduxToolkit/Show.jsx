import React from 'react'
import { useSelector } from 'react-redux'

function Show() {

    const counter = useSelector( (state)=>state.mycounter)
  return (
    <h1>Cart Items: {counter}</h1>
  )
}

export default Show