import React from 'react'
import { useSelector,useDispatch } from 'react-redux'
import { decrement, increment,reset } from './slice/counterslice'
import Show from './Show'
function App() {
    const counter = useSelector( (state)=>state.mycounter)
    const dispatch = useDispatch()
  return (
    <div>
<button onClick={ ()=> dispatch( increment())}>Increment</button>
{counter}
<button onClick={ ()=> dispatch( decrement())}>Decrement</button>
    <button onClick={()=>dispatch(reset())}>reset</button>
    
    <br>
    </br>
    <Show/>
    </div>
  )
}

export default App