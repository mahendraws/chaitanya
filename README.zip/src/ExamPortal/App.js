import React from "react";
import OnlineExamPage from "./components/Online-Exam-Page/OnlineExamPage";

function App() {
  return (
    <>
      {/* <th>This is App Page</th> */}
      <OnlineExamPage />
    </>
  );
}

export default App;
