import React from "react";

function Aboutus() {
  return (
    <>
      <div>
        <div className="container">
          <h3>About US - Page</h3>
        </div>
      </div>
    </>
  );
}

export default Aboutus;
