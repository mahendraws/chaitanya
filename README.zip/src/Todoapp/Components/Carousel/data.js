export const sculptureList = [
  {
    id: "1",
    image:
      "https://media.sofa.com/thumbor/unsafe/fit-in/440x220/center/middle/https%3A%2F%2Fmedia.sofa.com%2Fmedias%2F%3Fcontext%3DbWFzdGVyfHJvb3R8MTk5MDU5fGltYWdlL2pwZWd8aGMxL2gyYi85MDE1NTUzNjU0ODE0LmpwZ3w3M2IyYmQzZmE3M2U2YmQ4ZDg5N2EyNTAwOWE0NjI2OWJlZmUyM2YzNTIxMmM3ZTU3ZDZkZjg1ODgyNzg4ODU4",
    Name: "Bowie Alderney Sofa",
    price: "₹ : 25,000/-",
    Category: "Sofa",
    About:
      "Classic, effortlessly good looks, and timeless appeal, our collection of traditional armchairs offers supreme comfort and style.",
  },
  {
    id: "2",
    image: "https://m.media-amazon.com/images/I/71H7tMBS8CL._SL1500_.jpg",
    Name: "boAt Airdopes",
    price: "₹ : 1,499/-",
    Category: "Airdopes",
    About:
      "boAt Airdopes 141 Bluetooth TWS in Ear Earbuds with 42H Playtime,Low Latency Mode for Gaming, ENx Tech, IWP, IPX4 Water Resistance, Smooth Touch...",
  },
  {
    id: "3",
    image: "https://m.media-amazon.com/images/I/81FsR58fGwL._SL1500_.jpg",
    Name: "Bluebell Armchair",
    price: "₹ : 55,999/-",
    Category: "Chair",
    About:
      "Classic, effortlessly good looks, and timeless appeal, our collection of traditional armchairs offers supreme comfort and style.",
  },
  {
    id: "4",
    image:
      "https://media.sofa.com/thumbor/unsafe/fit-in/440x220/center/middle/https%3A%2F%2Fmedia.sofa.com%2Fmedias%2F%3Fcontext%3DbWFzdGVyfHJvb3R8Nzg5OTgwfGltYWdlL2pwZWd8aGZmL2g1MC84OTAzOTUyMTA1NTAyLmpwZ3xkMmFlMzIyOGRmMTRiZTkxMGI5OTFmYTU3NGQxNzJmMzZhZDViYzVlMGM2YTAxNGI3NDBkNWUxMzMwNjU3YzZj",
    Name: "Duke Armchair",
    price: "₹ : 31,000/-",
    Category: "Chair",
    About:
      "Classic, effortlessly good looks, and timeless appeal, our collection of traditional armchairs offers supreme comfort and style.",
  },
  {
    id: "5",
    image:
      "https://media.sofa.com/thumbor/unsafe/fit-in/440x220/center/middle/https%3A%2F%2Fmedia.sofa.com%2Fmedias%2F%3Fcontext%3DbWFzdGVyfHJvb3R8MjIyNzd8aW1hZ2UvanBlZ3xoMjYvaDYzLzg4NTYzMzQyMzc3MjYuanBnfGZjYjgyYjRiODQ1ZmI4ZDJmNGEyZjU3MDc2N2I0NWUxNDA1ODY1OTc5MGNkNDMzZjA2YTk3NTIyMWRkODZjNDA",
    Name: "Betty Armchair",
    price: "₹ : 67,000/-",
    Category: "Chair",
    About:
      "Classic, effortlessly good looks, and timeless appeal, our collection of traditional armchairs offers supreme comfort and style.",
  },
  {
    id: "6",
    image: "https://m.media-amazon.com/images/I/71LfnkRgZ4L._SL1500_.jpg",
    Name: "Apple Watch SE",
    price: "₹ : 29,999/-",
    Category: "Watch",
    About:
      "Apple Watch SE (2nd Gen) [GPS 40 mm] Smart Watch w/Silver Aluminium Case & White Sport Band. Fitness & Sleep Tracker, Crash Detection, Heart Rate Monitor, Retina Display,",
    Services: "1 Year Warranty,No Returns Applicable,GST invoice available",
  },
  {
    id: "7",
    image:
      "https://media.sofa.com/thumbor/unsafe/fit-in/440x220/center/middle/https%3A%2F%2Fmedia.sofa.com%2Fmedias%2F%3Fcontext%3DbWFzdGVyfHJvb3R8ODUxODd8aW1hZ2UvanBlZ3xoMmQvaDAzLzg5MDkxNTQ5NzU3NzQuanBnfDAwZWQzNTFiYjlkZDc5ODVhZjk5NDBjNmEzOTM0NmNlYjYyODlmNDZjYWVjYzA2ZGJiZTNhOTY1MzgwMTY3ZGI",
    Name: "Cecil Dog Bed",
    price: "₹: 6,000/-",
    Category: "Petbed",

    About:
      " This petbed raises Currency question in British India, which led to the Creation of Reserve Bank of India.THE PROBLEM OF THE RUPEE was first published in 1923.",
  },
  {
    id: "8",
    image:
      "https://media.sofa.com/thumbor/unsafe/fit-in/440x220/center/middle/https%3A%2F%2Fmedia.sofa.com%2Fmedias%2F%3Fcontext%3DbWFzdGVyfHJvb3R8NTY1MzN8aW1hZ2UvanBlZ3xoODUvaDEyLzg4NTYwMTE4NjYxNDIuanBnfGUxZGRlMjY5M2ViNWZhNTEyZGIwMTExNDcwZDk4NDk2YmFhN2M4Yjc0NzYwMDEyNDI1MDQxMDY2ZWI2MjRkYWM",
    Name: "Knightsbridge With Footboard Bed",
    price: "₹ : 30,999/-",
    Category: "Bed",
    About: "There really is nothing better than a great night’s sleep.  ",
  },
  {
    id: "9",
    image:
      "https://www.apple.com/v/airpods-max/e/images/overview/design_colors_pink_front__dbqafvrvcy6a_xlarge.jpg",
    Name: "APPLE New AirPods ",
    price: "₹ : 44,999/-",
    Category: "Airpods",
    About:
      ",Apple-designed dynamic driver provides high-fidelity audio,Active Noise Cancellation blocks outside noise, so you can immerse yourself in music,",
  },
  {
    id: "10",
    image:
      "https://media.sofa.com/thumbor/unsafe/fit-in/440x220/center/middle/https%3A%2F%2Fmedia.sofa.com%2Fmedias%2F%3Fcontext%3DbWFzdGVyfHJvb3R8MTUzNDQyfGltYWdlL2pwZWd8aGRmL2gwYi85MDE0NTI1Mzk0OTc0LmpwZ3xhOWNiYjI3YzMwOTg5N2YwMGFkMzRhNjY3ZmRkMWI2ZDVlNTQ2MDhmYjcxMzdkMWFiMDA4MTEyNDNmNzgzZWFl",
    Name: "Jack Armchair",
    price: "₹ : 39,000/-",
    Category: "Chair",
    About:
      "Classic, effortlessly good looks, and timeless appeal, our collection of traditional armchairs offers supreme comfort and style.",
  },
  {
    id: "11",
    image:
      "https://www.apple.com/v/airpods-max/e/images/overview/design_colors_pink_front__dbqafvrvcy6a_xlarge.jpg",
    Name: "APPLE New AirPods ",
    price: "₹ : 44,999/-",
    quantity: "1",
    Category: "Airpods",
    About:
      ",Apple-designed dynamic driver provides high-fidelity audio,Active Noise Cancellation blocks outside noise, so you can immerse yourself in music,",
    Services: "1 Year Warranty,No Returns Applicable,GST invoice available",
  },
  {
    id: "12",
    image: "https://m.media-amazon.com/images/I/81lNRdMarjL._SL1500_.jpg",
    Name: "TIED RIBBONS Lord Buddha Meditating Statue Idol Showpiece",
    price: "₹ : 27,000/-",
    Category: "Phone",
    About:
      "17.00 cm (6.7-inch) Super Retina XDR display featuring Always-On and ProMotion,Dynamic Island, a magical new way to interact with iPhon,48MP Main camera for up to 4x greater resolution,Cinematic mode now in 4K Dolby Vision up to 30 fps",
  },
];
