import React, { useContext, useState } from "react";
import "./style.css";
import { Link } from "react-router-dom";

import "./SearchBox.css";
// Cosum Icons
import close from "../../assets/images/close.png";
import logo from '../../assets/images/logo.jpg'
import search from "../../assets/images/loupe.png";
import user from "../../assets/images/user.png";
import addtocart from "../../assets/images/cart.png";
import { useNavigate } from "react-router-dom";
import { ShopContext } from "../../contexts/shopContextProvider";
function Navigation() {

  const {cust_name,setCustName,setLogin,isLogin,cartItems,setCartProduct,setCustID,cartProduct} = useContext(ShopContext)
  // console.log(searchBox);
const navigate = useNavigate()

const logout=()=>{
 setLogin(false);
 setCustID(0)
 setCartProduct([]);
 setCustName("")
}
  return (
    <>


    </>
  );
}

export default Navigation;
